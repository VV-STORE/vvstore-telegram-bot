
import telebot
import gspread
from oauth2client.service_account import ServiceAccountCredentials
import os

BOT_TOKEN = os.getenv("BOT_TOKEN")
SHEET_URL = os.getenv("SHEET_URL")
GOOGLE_KEY = os.getenv("GOOGLE_KEY")

with open("google_key.json", "w") as f:
    f.write(GOOGLE_KEY)

scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/spreadsheets",
         "https://www.googleapis.com/auth/drive"]
creds = ServiceAccountCredentials.from_json_keyfile_name("google_key.json", scope)
client = gspread.authorize(creds)
sheet = client.open_by_url(SHEET_URL).sheet1

bot = telebot.TeleBot(BOT_TOKEN)

@bot.message_handler(func=lambda message: True)
def handle_message(message):
    lines = message.text.strip().split("\n")
    if len(lines) < 6:
        bot.reply_to(message, "❌ Неверный формат. Используй 6 строк: Модель, Цвет, Память, АКБ, Цена, Наличие.")
        return

    model = lines[0].strip()
    color = lines[1].strip()
    storage = lines[2].strip()
    battery = lines[3].strip()
    price = lines[4].strip()
    availability = lines[5].strip()

    if not price.startswith("$"):
        price = f"${price}"

    try:
        sheet.append_row([model, color, storage, battery, price, availability])
        bot.reply_to(message, f"✅ Добавлено в V&V STORE:\n{model}, {color}, {storage}, {battery}, {price}, {availability}")
    except Exception as e:
        bot.reply_to(message, f"❌ Ошибка при добавлении: {str(e)}")

bot.infinity_polling()
